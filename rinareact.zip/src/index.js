import React from 'react'
import ReactDOM from 'react-dom';
import {HashRouter, Route, Switch} from 'react-router-dom';
import App from '@/layout/App';
import DetailApp from '@/layout/DetailApp';
import './main.scss';
import 'antd-mobile/dist/antd-mobile.css';

ReactDOM.render(
    <HashRouter>
      <Switch>
        <Route path = '/detail' component = { DetailApp }></Route>
        <Route path = '/' component = { App } />
      </Switch>
    </HashRouter>,
    document.getElementById('root')
);
import React, { Component } from 'react'

export default class Com extends Component{
    render() {
        return(
            <div className={"content"}>个人中心</div>
        )
    }
}

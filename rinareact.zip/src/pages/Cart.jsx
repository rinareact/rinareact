import React, { Component } from 'react'

class Com extends Component{
    render() {
        return(
            <div className={"content"}>购物车</div>
        )
    }
}
export default Com
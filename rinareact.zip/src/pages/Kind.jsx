import React, { Component } from 'react'

class Com extends Component{
    render() {
        return(
            <div className={"content"}>分类</div>
        )
    }
}
export default Com